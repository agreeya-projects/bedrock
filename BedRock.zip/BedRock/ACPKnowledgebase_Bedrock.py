from pyexpat import model
from urllib import response
from flask import Flask, render_template, request, jsonify
from langchain_community.embeddings import OpenAIEmbeddings
from langchain.prompts import ChatPromptTemplate
from langchain.chains import ConversationChain
from langchain.chains.conversation.memory import ConversationBufferWindowMemory
from flask_cors import CORS
from langchain_openai import OpenAI
import tiktoken
import ast
from langchain_openai import ChatOpenAI
from langchain_mongodb import MongoDBAtlasVectorSearch
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain.memory import ConversationSummaryMemory, ConversationSummaryBufferMemory
from openai import OpenAI as openai_OpenAI
import boto3
from langchain.embeddings import HuggingFaceEmbeddings
from utils import set_open_key
import os
import json
import subprocess
import torch
from transformers import LlamaForCausalLM, LlamaTokenizer
from traceloop.sdk import Traceloop
import json
Traceloop.init(disable_batch=True, api_key="3ae8af7193600223d1f97b3f11c20db69675b107b6276770fb77b632fbd1ff201b26fddcceb4e69e2d624452865a731d")

set_open_key()
app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Access the AWS credentials from environment variables
aws_access_key_id = os.getenv("AWS_ACCESS_KEY_ID")
aws_secret_access_key = os.getenv("AWS_SECRET_ACCESS_KEY")

client = openai_OpenAI()
model_name = "gpt-3.5-turbo-1106"
local_embedding_model_name = "BAAI/bge-small-en-v1.5"
loaded_db = {}
loaded_llm = {}
db_name = "llamaindex_db"
chat_history = {}
current_model_selected = ""
local_embedding = None
collection_name = None
llm = None
llm_agent = None
memory = None
conversation = None
gpu_tokenizer = None
gpu_model = None
atlas_connection_string = os.getenv("MONGODB_ATLAS_CLUSTER_URI")
gpu_device = 'cuda' if torch.cuda.is_available() else 'cpu'
print("System is using : ", gpu_device)
PROMPT_TEMPLATE = """
Answer the question using only the information provided in the following context. If the answer cannot be found in the context, and the user is not satisfied with the answer, say I am sorry and instruct them to raise an ACP ticket at the following URL: https://acp.verizon.com/jira/secure/Dashboard.jspa

Context:
{context}

History:
{history}

------------------

Question: {question}

Ensure to include the Page Reference Link from the end of the context chunk used to provide the answer. Do not include phrases like "based on the given context

"""
follow_up_ques_checker = """
Given the following conversation and a follow up question, 
rephrase the follow up question to be a standalone question, in its original language, 
that can be used to query a FAISS index. This query will be used to retrieve documents with additional context.

Let me share a couple examples.

If you do not see any chat history, you MUST return the "Follow Up Input" as is:
```
Chat History:
Follow Up Input: How is Lawrence doing?
Standalone Question:
How is Lawrence doing?
```

If this is the second question onwards, you should properly rephrase the question like this:
```
Chat History:
Human: How is Lawrence doing?
AI: 
Lawrence is injured and out for the season.
Follow Up Input: What was his injury?
Standalone Question:
What was Lawrence's injury?
```

Now, with those examples, here is the actual chat history and input question.
Chat History:
{chat_history}
Follow Up Input: {question}

output should be in the given json format.

{{
    "answer": "Standalone question"
}}

Do not provide any explanation, and anything apart from the answer in the json format.
"""

B_INST, E_INST= "[INST]", "[/INST]"
B_SYS, E_SYS = "<>\n", "\n<>\n\n"

DEFAULT_SYSTEM_PROMPT="""\
You are a helpful, respectful and honest assistant. Always answer as helpfully as possible, while being safe. Your answers should not include any harmful, unethical, racist, sexist, toxic, dangerous, or illegal content. Please ensure that your responses are socially unbiased and positive in nature.

If a question does not make any sense, or is not factually coherent, explain why instead of answering something not correct. If you don't know the answer to a question, please don't share false information.
"""

SYSTEM_PROMPT=B_SYS + DEFAULT_SYSTEM_PROMPT + E_SYS

# Read config_credentials.json
with open('page_link_info.json') as f:
    page_link_info = json.load(f)

def get_selected_model():
    if os.path.exists("selected_model.json"):
        with open('selected_model.json') as f:
            new_model_selected = json.load(f)["model"]
    else:
        new_model_selected = "openai"
    return new_model_selected

new_model_selected = get_selected_model()


def call_llm(prompt, new_model_selected, llm_agent):
    if new_model_selected.lower() == "openai":

        completion = client.chat.completions.create(
            model=model_name,
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": prompt}
            ]
        )

        print(completion.choices[0].message.content)
        answer = completion.choices[0].message.content
    else:
        answer = llm_agent(prompt)

    cleaned_content = answer.replace("```json", "").replace("```", "").strip()

    try:
        try:
            answer = cleaned_content["answer"]
        except:        
            answer = ast.literal_eval(str(cleaned_content))["answer"]
    except:
        pass
    return answer

def generate_response(prompt):
    with torch.no_grad():  # Disable gradient calculation
        inputs = gpu_tokenizer(prompt, return_tensors="pt").to('cuda' if torch.cuda.is_available() else 'cpu')
        outputs = gpu_model.generate(inputs.input_ids, max_length=128, temperature=0.01)
        response = gpu_tokenizer.decode(outputs[0], skip_special_tokens=True)
        return response


def get_vector_index_mongo_for_lang(local_embedding, collection_name_suffix, collection_name, atlas_connection_string, db_name):
    # Connect to your Atlas cluster
    if local_embedding == True:
        embed_model = HuggingFaceEmbeddings(model_name=local_embedding_model_name)
    else:
        embed_model = OpenAIEmbeddings()
    collection_name = collection_name# + "_" + collection_name_suffix
    vector_search = MongoDBAtlasVectorSearch.from_connection_string(
        atlas_connection_string,
        f"{db_name}.{collection_name}",
        embed_model,
        index_name=collection_name + "_index"
    )
    return vector_search

@app.route('/update_model', methods=['POST'])
def start_ingestion():
    log_file = 'update_model.txt'
    
    with open(log_file, 'w') as f:
        result = subprocess.run(
            ["python", "ACPModel.py"],
            stdout=f,
            stderr=f
        )
    success = result.returncode == 0
    return jsonify(success=success)

@app.route('/query', methods=['POST'])
def query():
    global model_name
    global local_embedding_model_name
    global loaded_db
    global loaded_llm
    global db_name
    global chat_history
    global current_model_selected
    global local_embedding
    global collection_name
    global llm
    global llm_agent
    global memory
    global conversation
    global gpu_tokenizer
    global gpu_model
    collection_name_suffix = "verizon"
    new_model_selected = get_selected_model()
    print(request.form)
    # user_id = request.form['user_id']
    user_id = "1"
    unique_id_confluence = request.form['unique_id_confluence']

    if user_id not in chat_history:
        chat_history[user_id] = []
    # current_model_selected = "openai"
    if current_model_selected != new_model_selected:
        if new_model_selected not in loaded_llm:
            if new_model_selected.lower() == "openai":
                local_embedding = False
                collection_name = "openai"
                llm = ChatOpenAI(model=model_name)
                llm_agent = openai_OpenAI
                loaded_llm[new_model_selected] = {"local_embedding": local_embedding, "collection_name": collection_name, "llm": llm, "llm_agent": llm_agent}

            elif new_model_selected.lower() == "llama2":
                if gpu_device == "cpu":
                    from langchain.llms import CTransformers
                    local_embedding = True
                    collection_name = "llama2"
                    llm=CTransformers(model="models/llama-2-7b-chat.ggmlv3.q4_K_M.bin",
                                    model_type="llama",
                                    config={'max_new_tokens':128,
                                            'temperature':0.01,
                                            'context_length': 4000})
                    llm_agent = llm
                    local_embedding = True
                    loaded_llm[new_model_selected] = {"local_embedding": local_embedding, "collection_name": collection_name, "llm": llm, "llm_agent": llm_agent}
                else:
                    model_name = "models/llama2GGMLModelsvc"
                    local_embedding = True
                    collection_name = "llama2"
                    gpu_tokenizer = LlamaTokenizer.from_pretrained(model_name)
                    torch.cuda.empty_cache()  # Clear CUDA cache
                    torch.cuda.set_per_process_memory_fraction(0.40, device=0)  # Set memory fraction
                    gpu_model = LlamaForCausalLM.from_pretrained(model_name).to('cuda' if torch.cuda.is_available() else 'cpu')
                    torch.backends.cudnn.benchmark = True  # Enable cuDNN benchmark for better performance
                    
                    llm_agent = generate_response
                    print("llama2ChatModel loaded with GPU support")
            
            elif new_model_selected.lower() == "bedrockmodel":
                bedrock = boto3.client(service_name="bedrock-runtime",
                                       aws_access_key_id=aws_access_key_id,
                                       aws_secret_access_key=aws_secret_access_key 
                                       )
                def call_bedrock_model(prompt):
                    payload = {
                        "prompt":"[INST]" + prompt + "[/INST]",
                        "max_gen_len":512,
                        "temperature":0.01,
                        "top_p":0.9
                    }
                    body = json.dumps(payload)
                    model_id = "meta.llama2-13b-chat-v1"
                    response = bedrock.invoke_model(
                        body=body,
                        modelId=model_id,
                        accept="application/json",
                        contentType="application/json"
                    )
                    response_body = json.loads(response.get("body").read())
                    return response_body['generation']
                
                local_embedding = True
                collection_name = "bedrock"
                llm = None
                llm_agent = call_bedrock_model
                loaded_llm[new_model_selected] = {"local_embedding": local_embedding, "collection_name": collection_name, "llm": llm, "llm_agent": llm_agent}
                            
            memory = ConversationBufferWindowMemory(llm=llm_agent, max_token_limit=4000)
            # Ensure llm is valid before creating a ConversationChain
            if llm is not None:
                conversation = ConversationChain(llm=llm, verbose=True)
                loaded_llm[new_model_selected]['conversation'] = conversation
            loaded_llm[new_model_selected]['memory'] = memory
            loaded_llm[new_model_selected]['conversation'] = conversation
        else:
            local_embedding = loaded_llm[new_model_selected]["local_embedding"]
            collection_name = loaded_llm[new_model_selected]["collection_name"]
            llm = loaded_llm[new_model_selected]["llm"]
            llm_agent = loaded_llm[new_model_selected]["llm_agent"]
            memory = loaded_llm[new_model_selected]["memory"]
            conversation = loaded_llm[new_model_selected]["conversation"]
        current_model_selected = new_model_selected
    if collection_name_suffix not in loaded_db:
        db = get_vector_index_mongo_for_lang(local_embedding, collection_name_suffix, collection_name, atlas_connection_string, db_name)
        loaded_db[collection_name_suffix] = db
    else:
        db = loaded_db[collection_name_suffix]

    query_text = request.form['query_text']
    print("Original Query: ", query_text)
    rephrase_prompt = """Please analyze the given text for grammatical errors and provide corrections. Focus on punctuation, sentence structure, and overall clarity to ensure a polished and error-free piece. 
    Input text: {user_query}
    output should be in the given json format.
    ```json
    {{
        "answer": "rephrased_query"
    }} 
    Do not include explanation and extra text apart from the rephrased query.
    """.format(user_query=query_text)
    if new_model_selected.lower() == "llama2":
        rephrase_prompt = B_INST + rephrase_prompt + E_INST
    query_text = call_llm(rephrase_prompt, new_model_selected, llm_agent)
    print("Rephrased Query: ", query_text)


    STANDALONE_QUESTION_PROMPT = follow_up_ques_checker.format(question=query_text, chat_history=chat_history[user_id])
    print(STANDALONE_QUESTION_PROMPT)
    if new_model_selected.lower() == "llama2":
        STANDALONE_QUESTION_PROMPT = B_INST + STANDALONE_QUESTION_PROMPT + E_INST
    query_text = call_llm(STANDALONE_QUESTION_PROMPT, new_model_selected, llm_agent)
    results = db.similarity_search_with_score(query_text, k=3, pre_filter={"metadata.unique_id": {"$eq": unique_id_confluence}})
    context_text = []
    for doc, _score in results:
        if "extension" in doc.metadata["metadata"]:
            filename =  doc.metadata["metadata"]["id"]
        else:
            filename = ".".join(doc.metadata["metadata"]["id"].split(".")[:-1])
        context_text.append(doc.page_content + "\n\n\nPage Link - " + page_link_info[unique_id_confluence][filename])
    context_text = "\n\n---\n\n".join(context_text)
    prompt_template = ChatPromptTemplate.from_template(PROMPT_TEMPLATE)
    _chat_history = chat_history[user_id]
    print("_chat_history", _chat_history)
    chat_history_len = len(_chat_history)
    if  chat_history_len > 5:
        _chat_history = _chat_history[-5:]
    prompt = prompt_template.format(context=context_text, history=_chat_history, question=query_text)
    if new_model_selected.lower() == "llama2":
        prompt = B_INST + prompt + E_INST
    # response_text = conversation.predict(input=prompt)
    response_text = call_llm(prompt, new_model_selected, llm_agent)
    
    print("_chat_history", _chat_history)
    _chat_history.append(f"User: {query_text} | Bot: {response_text}")
    chat_history[user_id] = _chat_history
    formatted_response_text = response_text
    print(formatted_response_text)
    return jsonify({
        'query_text': query_text,
        'response_text': formatted_response_text,
    })

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')